for i in 3
do
sleep 2s
python test20.py --edge_id $i&
done