for i in 0 1 2 
do
sleep 2s
python test4.py --edge_id $i&
done