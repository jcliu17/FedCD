for i in 0 1 2 3 4
do
sleep 1s
python test2.py --edge_id $i&
done