for i in 5 6 7
do
sleep 2s
python test46.py --edge_id $i&
done
