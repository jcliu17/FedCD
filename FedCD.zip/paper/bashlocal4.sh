for i in 0 1 2
do
sleep 2s
python test34.py --edge_id $i&
done