for i in 0 1 2 3 4 5
do
sleep 2s
python test48.py --edge_id $i&
done