for i in 3 4
do
sleep 2s
python test35.py --edge_id $i&
done